package com.shinobiarts;

import net.minecraftforge.common.ForgeConfigSpec;

/**
 * All balance values. This is a SERVER config: it lives in each world's serverconfig folder
 * (saves/WORLD/serverconfig/shinobiarts-server.toml) and Forge sends it to every client that joins,
 * so the HUD and menus always show the same numbers the server uses.
 * Use the b()/i()/d() helpers to read values safely even before a world is loaded.
 */
public final class Config {
    private static final ForgeConfigSpec.Builder B = new ForgeConfigSpec.Builder();

    // ---------------------------------------------------------------- general
    static { B.push("general"); }
    public static final ForgeConfigSpec.BooleanValue JUTSU_GRIEFING = B
            .comment("Allow jutsu and explosive tags to place fire, break plants/blocks and raise earth walls over grass.",
                     "The mobGriefing gamerule must also be true.")
            .define("jutsuGriefing", true);
    public static final ForgeConfigSpec.DoubleValue DAMAGE_MULTIPLIER = B
            .comment("Multiplier applied to all jutsu damage.").defineInRange("damageMultiplier", 1.0, 0.0, 10.0);
    public static final ForgeConfigSpec.DoubleValue COOLDOWN_MULTIPLIER = B
            .comment("Multiplier applied to all jutsu cooldowns.").defineInRange("cooldownMultiplier", 1.0, 0.0, 10.0);
    static { B.pop(); }

    // ---------------------------------------------------------------- chakra
    static { B.push("chakra"); }
    public static final ForgeConfigSpec.DoubleValue CHAKRA_REGEN_MULTIPLIER = B
            .comment("Multiplier applied to natural chakra regeneration and charging.").defineInRange("regenMultiplier", 1.0, 0.0, 10.0);
    public static final ForgeConfigSpec.DoubleValue BASE_CHAKRA_REGEN = B
            .comment("Chakra regenerated per second before bonuses (Uzumaki get 1.5x).").defineInRange("baseRegenPerSecond", 2.0, 0.0, 100.0);
    public static final ForgeConfigSpec.IntValue CHAKRA_PER_NINJUTSU = B
            .comment("Max chakra gained per Ninjutsu stat point.").defineInRange("chakraPerNinjutsuPoint", 5, 0, 1000);
    public static final ForgeConfigSpec.DoubleValue NINJUTSU_REGEN_PER_POINT = B
            .comment("Extra chakra regenerated per second per Ninjutsu point (0 to disable).").defineInRange("ninjutsuRegenPerPoint", 0.02, 0.0, 10.0);
    static { B.pop(); }

    // ---------------------------------------------------------------- leveling
    static { B.push("leveling"); }
    public static final ForgeConfigSpec.IntValue MAX_LEVEL = B.defineInRange("maxLevel", 100, 1, 10000);
    public static final ForgeConfigSpec.IntValue XP_BASE = B
            .comment("XP needed to go from level 1 to 2.").defineInRange("xpBase", 100, 1, 1000000);
    public static final ForgeConfigSpec.IntValue XP_PER_LEVEL = B
            .comment("Extra XP needed for each level after that (level N needs xpBase + (N-1) * xpPerLevel).")
            .defineInRange("xpPerLevel", 50, 0, 1000000);
    public static final ForgeConfigSpec.IntValue STAT_POINTS_PER_LEVEL = B.defineInRange("statPointsPerLevel", 3, 0, 100);
    public static final ForgeConfigSpec.IntValue RYO_PER_LEVEL_UP = B.defineInRange("ryoPerLevelUp", 250, 0, 1000000);
    public static final ForgeConfigSpec.IntValue EXP_BOTTLE_XP = B.defineInRange("expBottleXp", 100, 0, 1000000);
    public static final ForgeConfigSpec.BooleanValue TIER_REQUIREMENTS = B
            .comment("If true, tier 2 and 3 jutsu scrolls require a minimum level to learn.").define("tierRequirements", true);
    public static final ForgeConfigSpec.IntValue TIER2_LEVEL = B.defineInRange("tier2Level", 5, 1, 10000);
    public static final ForgeConfigSpec.IntValue TIER3_LEVEL = B.defineInRange("tier3Level", 15, 1, 10000);
    static { B.pop(); }

    // ---------------------------------------------------------------- stats
    static { B.push("stats"); }
    public static final ForgeConfigSpec.IntValue STAT_CAP = B
            .comment("Maximum points in any one stat (Speed has its own cap).").defineInRange("statCap", 100, 1, 10000);
    public static final ForgeConfigSpec.IntValue SPEED_CAP = B.defineInRange("speedCap", 50, 1, 10000);
    public static final ForgeConfigSpec.DoubleValue HEALTH_PER_MEDICAL = B
            .comment("Max health per Medical point (2 = one heart).").defineInRange("healthPerMedicalPoint", 1.0, 0.0, 100.0);
    public static final ForgeConfigSpec.DoubleValue SPEED_PER_POINT = B
            .comment("Movement speed bonus per Speed point (0.01 = +1%).").defineInRange("speedPerPoint", 0.01, 0.0, 1.0);
    public static final ForgeConfigSpec.DoubleValue TAIJUTSU_PER_POINT = B
            .comment("Extra fist damage per Taijutsu point.").defineInRange("taijutsuDamagePerPoint", 0.5, 0.0, 100.0);
    public static final ForgeConfigSpec.DoubleValue KENJUTSU_PER_POINT = B
            .comment("Extra sword damage per Kenjutsu point.").defineInRange("kenjutsuDamagePerPoint", 0.4, 0.0, 100.0);
    public static final ForgeConfigSpec.DoubleValue GENJUTSU_PER_POINT = B
            .comment("Genjutsu bonus per point: longer illusions/binds, stronger Amaterasu, better Sharingan dodge (0.02 = +2%).")
            .defineInRange("genjutsuBonusPerPoint", 0.02, 0.0, 1.0);
    public static final ForgeConfigSpec.IntValue SENJUTSU_PER_POINT = B
            .comment("Max Senjutsu (natural energy) per Senjutsu point.").defineInRange("senjutsuPerPoint", 10, 0, 1000);
    public static final ForgeConfigSpec.IntValue RESET_COST_BASE = B
            .comment("Ryo cost to reset stats = base + perLevel * level.").defineInRange("statResetCostBase", 500, 0, 100000000);
    public static final ForgeConfigSpec.IntValue RESET_COST_PER_LEVEL = B.defineInRange("statResetCostPerLevel", 100, 0, 100000000);
    static { B.pop(); }

    // ---------------------------------------------------------------- senjutsu
    static { B.push("senjutsu"); }
    public static final ForgeConfigSpec.DoubleValue SENJUTSU_GATHER_RATE = B
            .comment("Natural energy gathered per second while charging chakra and standing still.").defineInRange("gatherPerSecond", 4.0, 0.0, 1000.0);
    public static final ForgeConfigSpec.DoubleValue SAGE_MODE_DRAIN = B
            .comment("Senjutsu drained per second in Sage Mode.").defineInRange("sageModeDrainPerSecond", 2.0, 0.0, 1000.0);
    public static final ForgeConfigSpec.IntValue SAGE_MODE_MIN = B
            .comment("Senjutsu needed to enter Sage Mode.").defineInRange("sageModeMinimum", 20, 0, 100000);
    public static final ForgeConfigSpec.DoubleValue SAGE_MODE_JUTSU_BONUS = B
            .comment("Extra jutsu damage in Sage Mode (0.25 = +25%).").defineInRange("sageModeJutsuBonus", 0.25, 0.0, 10.0);
    static { B.pop(); }

    // ---------------------------------------------------------------- movement
    static { B.push("ninjaJump"); }
    public static final ForgeConfigSpec.IntValue NINJA_JUMP_COST = B.defineInRange("chakraCost", 15, 0, 100000);
    public static final ForgeConfigSpec.IntValue NINJA_JUMP_COOLDOWN = B
            .comment("Cooldown in ticks (20 = 1 second).").defineInRange("cooldownTicks", 30, 0, 72000);
    public static final ForgeConfigSpec.DoubleValue NINJA_JUMP_POWER = B
            .comment("Multiplier for how far the jump launches you.").defineInRange("power", 1.0, 0.1, 5.0);
    static { B.pop(); }

    public static final ForgeConfigSpec SPEC = B.build();

    // ---------------------------------------------------------------- safe readers
    public static boolean b(ForgeConfigSpec.BooleanValue v) {
        try {
            return v.get();
        } catch (RuntimeException e) {
            return v.getDefault();
        }
    }

    public static int i(ForgeConfigSpec.IntValue v) {
        try {
            return v.get();
        } catch (RuntimeException e) {
            return v.getDefault();
        }
    }

    public static double d(ForgeConfigSpec.DoubleValue v) {
        try {
            return v.get();
        } catch (RuntimeException e) {
            return v.getDefault();
        }
    }

    public static float f(ForgeConfigSpec.DoubleValue v) {
        return (float) d(v);
    }

    private Config() {}
}
