package com.shinobiarts.item;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import com.shinobiarts.entity.ThrownToolEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/** Kunai and shuriken: right-click to throw, and (for kunai) a light melee weapon. */
public class ThrownToolItem extends Item {
    private final float throwSpeed;
    private final int cooldown;
    @Nullable
    private final Multimap<Attribute, AttributeModifier> meleeModifiers;

    public ThrownToolItem(Properties properties, float throwSpeed, int cooldownTicks, double meleeDamageBonus, double attackSpeedModifier) {
        super(properties);
        this.throwSpeed = throwSpeed;
        this.cooldown = cooldownTicks;
        if (meleeDamageBonus > 0) {
            ImmutableMultimap.Builder<Attribute, AttributeModifier> builder = ImmutableMultimap.builder();
            builder.put(Attributes.ATTACK_DAMAGE, new AttributeModifier(BASE_ATTACK_DAMAGE_UUID, "Weapon modifier", meleeDamageBonus, AttributeModifier.Operation.ADDITION));
            builder.put(Attributes.ATTACK_SPEED, new AttributeModifier(BASE_ATTACK_SPEED_UUID, "Weapon modifier", attackSpeedModifier, AttributeModifier.Operation.ADDITION));
            this.meleeModifiers = builder.build();
        } else {
            this.meleeModifiers = null;
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public Multimap<Attribute, AttributeModifier> getDefaultAttributeModifiers(EquipmentSlot slot) {
        return slot == EquipmentSlot.MAINHAND && meleeModifiers != null ? meleeModifiers : super.getDefaultAttributeModifiers(slot);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        level.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.TRIDENT_THROW, SoundSource.PLAYERS, 0.5f, 1.6f);
        if (!level.isClientSide) {
            ThrownToolEntity thrown = new ThrownToolEntity(level, player);
            ItemStack single = stack.copy();
            single.setCount(1);
            thrown.setItem(single);
            thrown.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0f, throwSpeed, 0.5f);
            level.addFreshEntity(thrown);
        }
        player.getCooldowns().addCooldown(this, cooldown);
        player.awardStat(Stats.ITEM_USED.get(this));
        if (!player.getAbilities().instabuild) stack.shrink(1);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.shinobiarts.throwable").withStyle(ChatFormatting.GRAY));
    }
}
