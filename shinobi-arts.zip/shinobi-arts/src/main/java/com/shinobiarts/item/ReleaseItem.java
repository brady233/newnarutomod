package com.shinobiarts.item;

import com.shinobiarts.client.ClientNinjaData;
import com.shinobiarts.jutsu.Jutsu;
import com.shinobiarts.ninja.ChakraNature;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/**
 * A release scroll. Holding one (main hand or off hand) equips that release: the HUD shows its
 * jutsu slots, the arrow keys move between them, and the cast key uses the selected one.
 * Learning a jutsu from a scroll adds it to the slots of its release.
 */
public class ReleaseItem extends Item {
    private final ChakraNature release;

    public ReleaseItem(ChakraNature release, Properties properties) {
        super(properties);
        this.release = release;
    }

    public ChakraNature release() {
        return release;
    }

    /** The release the player is currently holding (main hand first), or null. */
    @Nullable
    public static ChakraNature heldRelease(Player player) {
        for (InteractionHand hand : InteractionHand.values()) {
            if (player.getItemInHand(hand).getItem() instanceof ReleaseItem item) return item.release;
        }
        return null;
    }

    /** Gives the player this release's scroll (dropped at their feet if the inventory is full). */
    public static void give(net.minecraft.server.level.ServerPlayer player, ChakraNature release) {
        ItemStack stack = new ItemStack(com.shinobiarts.registry.ModItems.release(release));
        player.getInventory().add(stack);
        if (!stack.isEmpty()) player.drop(stack, false);
        player.sendSystemMessage(Component.translatable("message.shinobiarts.release_given", release.displayName()).withStyle(ChatFormatting.AQUA));
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.shinobiarts.release_hold").withStyle(ChatFormatting.GRAY));
        if (level == null || !level.isClientSide) return;
        NinjaData d = ClientNinjaData.get();
        if (!d.hasNature(release)) {
            tooltip.add(Component.translatable("tooltip.shinobiarts.release_locked").withStyle(ChatFormatting.RED));
            return;
        }
        List<Jutsu> slots = d.slots(release);
        if (slots.isEmpty()) {
            tooltip.add(Component.translatable("tooltip.shinobiarts.release_empty").withStyle(ChatFormatting.DARK_GRAY));
        } else {
            for (Jutsu j : slots) tooltip.add(Component.literal(" - ").append(j.displayName()));
        }
    }
}
