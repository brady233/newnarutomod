package com.shinobiarts.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Kubikiribocho, the giant cleaver. A sword, so Kenjutsu points boost it. Like the legend,
 * it repairs itself a little with every hit that lands.
 */
public class ZabuzaBladeItem extends SwordItem {
    public ZabuzaBladeItem(Tier tier, int attackDamage, float attackSpeed, Properties properties) {
        super(tier, attackDamage, attackSpeed, properties);
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        boolean result = super.hurtEnemy(stack, target, attacker);
        if (stack.isDamaged()) stack.setDamageValue(Math.max(0, stack.getDamageValue() - 3));
        return result;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.shinobiarts.zabuza_blade").withStyle(ChatFormatting.GRAY));
    }
}
