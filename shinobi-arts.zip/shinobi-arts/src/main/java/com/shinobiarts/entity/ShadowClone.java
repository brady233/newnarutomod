package com.shinobiarts.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.EnumSet;
import java.util.Optional;
import java.util.UUID;

/**
 * A solid copy of its owner. Wears the owner's skin and gear, follows them, fights whatever they
 * fight, and disappears in a puff of smoke after 30 seconds or the moment it takes any hit.
 */
public class ShadowClone extends PathfinderMob {
    private static final EntityDataAccessor<Optional<UUID>> OWNER = SynchedEntityData.defineId(ShadowClone.class, EntityDataSerializers.OPTIONAL_UUID);
    public static final int LIFETIME = 600;

    private int life = LIFETIME;
    private int ownerMissingTicks;

    public ShadowClone(EntityType<? extends ShadowClone> type, Level level) {
        super(type, level);
        this.xpReward = 0;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 2.0)
                .add(Attributes.MOVEMENT_SPEED, 0.32)
                .add(Attributes.ATTACK_DAMAGE, 3.0)
                .add(Attributes.FOLLOW_RANGE, 32.0);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(OWNER, Optional.empty());
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.3, true));
        this.goalSelector.addGoal(2, new FollowOwnerGoal(this));
        this.goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 8.0f));
        this.goalSelector.addGoal(4, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Monster.class, 5, true, false,
                target -> !(target instanceof Creeper)));
    }

    // ---------------------------------------------------------------- owner

    public void setOwner(Player owner) {
        this.entityData.set(OWNER, Optional.of(owner.getUUID()));
    }

    @Nullable
    public UUID getOwnerUUID() {
        return this.entityData.get(OWNER).orElse(null);
    }

    @Nullable
    public Player getOwner() {
        UUID id = getOwnerUUID();
        return id == null ? null : level().getPlayerByUUID(id);
    }

    private boolean isFriendly(Entity other) {
        UUID id = getOwnerUUID();
        if (id == null) return false;
        if (id.equals(other.getUUID())) return true;
        return other instanceof ShadowClone clone && id.equals(clone.getOwnerUUID());
    }

    @Override
    public boolean isAlliedTo(Entity other) {
        return isFriendly(other) || super.isAlliedTo(other);
    }

    @Override
    public boolean canAttack(LivingEntity target) {
        return !isFriendly(target) && super.canAttack(target);
    }

    /** Copies the owner's held items and armor (cosmetic + weapon damage; never dropped). */
    public void copyEquipment(Player owner) {
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            setItemSlot(slot, owner.getItemBySlot(slot).copy());
            setDropChance(slot, 0.0f);
        }
    }

    // ---------------------------------------------------------------- behaviour

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide || isRemoved()) return;
        if (--life <= 0) {
            poof();
            return;
        }
        Player owner = getOwner();
        if (owner == null || !owner.isAlive()) {
            if (++ownerMissingTicks > 40) poof();
            return;
        }
        ownerMissingTicks = 0;
        if (tickCount % 10 == 0) followOwnersFight(owner);
    }

    private void followOwnersFight(Player owner) {
        LivingEntity hit = owner.getLastHurtMob();
        if (hit != null && hit.isAlive() && hit != this && !isFriendly(hit)
                && owner.tickCount - owner.getLastHurtMobTimestamp() < 100) {
            if (getTarget() != hit) setTarget(hit);
            return;
        }
        LivingEntity attacker = owner.getLastHurtByMob();
        if (attacker != null && attacker.isAlive() && attacker != this && !isFriendly(attacker) && getTarget() != attacker) {
            setTarget(attacker);
        }
    }

    /** Any hit dispels the clone. */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (level().isClientSide || isRemoved()) return false;
        if (isInvulnerableTo(source)) return false;
        poof();
        return true;
    }

    public void poof() {
        if (level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.POOF, getX(), getY() + 1.0, getZ(), 25, 0.3, 0.6, 0.3, 0.03);
            server.playSound(null, getX(), getY(), getZ(), SoundEvents.FIRE_EXTINGUISH, SoundSource.NEUTRAL, 0.6f, 1.7f);
        }
        discard();
    }

    void teleportNear(Player owner) {
        double x = owner.getX() + (random.nextDouble() - 0.5) * 3.0;
        double z = owner.getZ() + (random.nextDouble() - 0.5) * 3.0;
        teleportTo(x, owner.getY(), z);
        getNavigation().stop();
    }

    @Override
    public boolean removeWhenFarAway(double distanceSqr) {
        return false;
    }

    @Override
    protected boolean shouldDropLoot() {
        return false;
    }

    // ---------------------------------------------------------------- save

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        UUID id = getOwnerUUID();
        if (id != null) tag.putUUID("Owner", id);
        tag.putInt("Life", life);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("Owner")) this.entityData.set(OWNER, Optional.of(tag.getUUID("Owner")));
        if (tag.contains("Life")) life = tag.getInt("Life");
    }

    // ---------------------------------------------------------------- goals

    static class FollowOwnerGoal extends Goal {
        private final ShadowClone clone;
        @Nullable
        private Player owner;
        private int recalc;

        FollowOwnerGoal(ShadowClone clone) {
            this.clone = clone;
            setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            Player o = clone.getOwner();
            if (o == null || o.isSpectator() || clone.getTarget() != null) return false;
            if (clone.distanceToSqr(o) < 16.0) return false;
            owner = o;
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            return owner != null && owner.isAlive() && clone.getTarget() == null && clone.distanceToSqr(owner) > 6.25;
        }

        @Override
        public void start() {
            recalc = 0;
        }

        @Override
        public void stop() {
            owner = null;
            clone.getNavigation().stop();
        }

        @Override
        public void tick() {
            if (owner == null) return;
            clone.getLookControl().setLookAt(owner, 10.0f, clone.getMaxHeadXRot());
            if (--recalc <= 0) {
                recalc = 10;
                if (clone.distanceToSqr(owner) > 400.0) clone.teleportNear(owner);
                else clone.getNavigation().moveTo(owner, 1.25);
            }
        }
    }
}
