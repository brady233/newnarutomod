package com.shinobiarts.ninja;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;

import javax.annotation.Nullable;

/**
 * The chakra natures (five elements + Yin Yang), plus NONE which is the general "Ninjutsu" release
 * (non-elemental and clan techniques). Each value is also a release the player can equip.
 * To add a nature: add it here, add its icon to textures/nature/, its release item model and its lang entries.
 */
public enum ChakraNature {
    FIRE("fire", ChatFormatting.RED, 0xD9301C),
    WATER("water", ChatFormatting.BLUE, 0x2A8CF0),
    WIND("wind", ChatFormatting.GREEN, 0x22B97A),
    LIGHTNING("lightning", ChatFormatting.YELLOW, 0xDCCB12),
    EARTH("earth", ChatFormatting.GOLD, 0x8E5A24),
    YIN_YANG("yin_yang", ChatFormatting.DARK_PURPLE, 0x7A4FB0),
    NONE("ninjutsu", ChatFormatting.LIGHT_PURPLE, 0xB07CF0);

    /** The five basic elements a ninja can be born with. */
    public static final ChakraNature[] ELEMENTS = {FIRE, WATER, WIND, LIGHTNING, EARTH};
    /** All natures: the five elements plus Yin Yang (one combined release). */
    public static final ChakraNature[] NATURES = {FIRE, WATER, WIND, LIGHTNING, EARTH, YIN_YANG};
    /** Every equippable release: the natures plus Ninjutsu. */
    public static final ChakraNature[] RELEASES = {FIRE, WATER, WIND, LIGHTNING, EARTH, YIN_YANG, NONE};

    private final String id;
    private final ChatFormatting color;
    private final int rgb;

    ChakraNature(String id, ChatFormatting color, int rgb) {
        this.id = id;
        this.color = color;
        this.rgb = rgb;
    }

    public String id() {
        return id;
    }

    public ChatFormatting color() {
        return color;
    }

    /** Colour used for HUD elements (0xRRGGBB). */
    public int rgb() {
        return rgb;
    }

    /** True for the seven natures, false for the Ninjutsu release. */
    public boolean isElement() {
        return this != NONE;
    }

    public MutableComponent displayName() {
        return Component.translatable("nature.shinobiarts." + id).withStyle(color);
    }

    /** 64x64 icon shown in the HUD and menus. */
    public ResourceLocation icon() {
        return new ResourceLocation("shinobiarts", "textures/nature/" + id + ".png");
    }

    @Nullable
    public static ChakraNature byId(String id) {
        for (ChakraNature n : values()) {
            if (n.id.equals(id)) return n;
        }
        // older saves used "none" for Ninjutsu and had separate Yin and Yang releases
        if ("none".equals(id)) return NONE;
        if ("yin".equals(id) || "yang".equals(id)) return YIN_YANG;
        return null;
    }
}
