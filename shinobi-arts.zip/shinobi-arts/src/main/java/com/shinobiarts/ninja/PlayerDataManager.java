package com.shinobiarts.ninja;

import com.shinobiarts.Config;
import com.shinobiarts.item.CoinItem;
import com.shinobiarts.item.FrogWalletItem;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

import javax.annotation.Nullable;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.UUID;

/**
 * The single entry point for changing player progression and resources. Every system (stat menu,
 * leveling, Ryo, wallet, commands) goes through here so values are validated on the server,
 * stat effects are re-applied, and the client copy is synced. Never trust values sent by a client.
 */
public final class PlayerDataManager {
    private static final UUID MEDICAL_HEALTH_ID = UUID.fromString("6f1d9a3e-5b2c-4c1e-9a7d-1e2f3a4b5c6d");
    private static final UUID SPEED_ID = UUID.fromString("0b7c2e4d-8a1f-4d3b-b6c9-7e8f9a0b1c2d");

    private PlayerDataManager() {}

    @Nullable
    public static NinjaData get(ServerPlayer player) {
        return NinjaData.get(player);
    }

    public static void sync(ServerPlayer player) {
        ModNetwork.sync(player);
    }

    // ================================================================ stat effects

    /** Re-applies Medical (max health) and Speed (movement) from the player's stats. */
    public static void applyStatEffects(ServerPlayer player) {
        NinjaData d = NinjaData.get(player);
        if (d == null) return;

        AttributeInstance health = player.getAttribute(Attributes.MAX_HEALTH);
        if (health != null) {
            health.removeModifier(MEDICAL_HEALTH_ID);
            double bonus = d.stat(Stat.MEDICAL) * Config.d(Config.HEALTH_PER_MEDICAL);
            if (bonus > 0) {
                health.addPermanentModifier(new AttributeModifier(MEDICAL_HEALTH_ID, "Shinobi Arts medical",
                        bonus, AttributeModifier.Operation.ADDITION));
            }
            if (player.getHealth() > player.getMaxHealth()) player.setHealth(player.getMaxHealth());
        }

        AttributeInstance speed = player.getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed != null) {
            speed.removeModifier(SPEED_ID);
            int points = Math.min(d.stat(Stat.SPEED), Config.i(Config.SPEED_CAP));
            double bonus = points * Config.d(Config.SPEED_PER_POINT);
            if (bonus > 0) {
                speed.addPermanentModifier(new AttributeModifier(SPEED_ID, "Shinobi Arts speed",
                        bonus, AttributeModifier.Operation.MULTIPLY_BASE));
            }
        }

        d.setChakra(d.getChakra());
        d.setSenjutsu(d.getSenjutsu());
    }

    // ================================================================ leveling

    /** Adds XP, handling any number of level-ups (stat points + Ryo reward each). */
    public static void addXp(ServerPlayer player, long amount) {
        NinjaData d = NinjaData.get(player);
        if (d == null || amount <= 0) return;
        if (d.isMaxLevel()) {
            d.setXp(0);
            sync(player);
            return;
        }
        long xp = d.getXp() + amount;
        int levelsGained = 0;
        long ryoGained = 0;
        while (!d.isMaxLevel() && xp >= d.xpToNext()) {
            xp -= d.xpToNext();
            d.setLevel(d.getLevel() + 1);
            d.setEarnedPoints(d.getEarnedPoints() + Config.i(Config.STAT_POINTS_PER_LEVEL));
            ryoGained += Config.i(Config.RYO_PER_LEVEL_UP);
            levelsGained++;
        }
        d.setXp(d.isMaxLevel() ? 0 : xp);
        if (ryoGained > 0) d.setRyo(d.getRyo() + ryoGained);

        if (levelsGained > 0) {
            player.sendSystemMessage(Component.translatable("message.shinobiarts.level_up", d.getLevel(),
                    levelsGained * Config.i(Config.STAT_POINTS_PER_LEVEL), formatRyo(ryoGained)).withStyle(ChatFormatting.GOLD));
            player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.PLAYER_LEVELUP,
                    SoundSource.PLAYERS, 1.0f, 1.0f);
            player.serverLevel().sendParticles(ParticleTypes.TOTEM_OF_UNDYING, player.getX(), player.getY() + 1, player.getZ(),
                    40, 0.5, 0.8, 0.5, 0.3);
        }
        sync(player);
    }

    /** Admin: set level directly. Earned points are recalculated so the totals stay consistent. */
    public static void setLevel(ServerPlayer player, int level) {
        NinjaData d = NinjaData.get(player);
        if (d == null) return;
        int clamped = Math.max(1, Math.min(level, Config.i(Config.MAX_LEVEL)));
        d.setLevel(clamped);
        d.setXp(0);
        int earned = (clamped - 1) * Config.i(Config.STAT_POINTS_PER_LEVEL);
        d.setEarnedPoints(Math.max(earned, d.allocatedPoints()));
        sync(player);
    }

    // ================================================================ stats

    /** Spends stat points. Returns false (and tells the player why) if the request is invalid. */
    public static boolean allocate(ServerPlayer player, Stat stat, int amount) {
        NinjaData d = NinjaData.get(player);
        if (d == null || amount <= 0) return false;
        int room = stat.cap() - d.stat(stat);
        int spend = Math.min(amount, Math.min(room, d.availablePoints()));
        if (spend <= 0) {
            player.displayClientMessage(Component.translatable(room <= 0 ? "message.shinobiarts.stat_capped"
                    : "message.shinobiarts.no_points").withStyle(ChatFormatting.RED), true);
            return false;
        }
        d.setStat(stat, d.stat(stat) + spend);
        applyStatEffects(player);
        sync(player);
        return true;
    }

    /** Refunds every allocated point for Ryo. Validated entirely on the server. */
    public static boolean resetStats(ServerPlayer player) {
        NinjaData d = NinjaData.get(player);
        if (d == null) return false;
        if (d.allocatedPoints() == 0) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.nothing_to_reset").withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        long cost = d.resetCost();
        if (d.getRyo() < cost) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.not_enough_ryo",
                    formatRyo(cost), formatRyo(d.getRyo())).withStyle(ChatFormatting.RED), true);
            return false;
        }
        d.setRyo(d.getRyo() - cost);
        d.clearStats();
        d.setSageMode(false);
        applyStatEffects(player);
        player.sendSystemMessage(Component.translatable("message.shinobiarts.stats_reset", formatRyo(cost)).withStyle(ChatFormatting.YELLOW));
        sync(player);
        return true;
    }

    // ================================================================ ryo

    public static void addRyo(ServerPlayer player, long amount) {
        NinjaData d = NinjaData.get(player);
        if (d == null || amount <= 0) return;
        d.setRyo(d.getRyo() + amount);
        sync(player);
    }

    /** Takes Ryo if the player has enough. Returns whether it was taken. */
    public static boolean trySpendRyo(ServerPlayer player, long amount) {
        NinjaData d = NinjaData.get(player);
        if (d == null || amount < 0 || d.getRyo() < amount) return false;
        d.setRyo(d.getRyo() - amount);
        sync(player);
        return true;
    }

    public static void setRyo(ServerPlayer player, long amount) {
        NinjaData d = NinjaData.get(player);
        if (d == null) return;
        d.setRyo(amount);
        sync(player);
    }

    /** The wallet is only usable while one is in the player's inventory. */
    public static boolean hasWallet(ServerPlayer player) {
        Inventory inv = player.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            if (inv.getItem(i).getItem() instanceof FrogWalletItem) return true;
        }
        return false;
    }

    /**
     * Moves coins from the inventory into the player's Ryo. {@code only} limits it to one coin type
     * (null = all coins). Runs on the server thread, so removing the items and adding the Ryo is atomic.
     */
    public static void deposit(ServerPlayer player, @Nullable CoinItem.Coin only) {
        NinjaData d = NinjaData.get(player);
        if (d == null || !hasWallet(player)) return;
        Inventory inv = player.getInventory();
        long total = 0;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (stack.getItem() instanceof CoinItem coin && (only == null || coin.coin() == only)) {
                total += (long) coin.coin().value() * stack.getCount();
                inv.setItem(i, ItemStack.EMPTY);
            }
        }
        if (total == 0) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.no_coins").withStyle(ChatFormatting.GRAY), true);
            return;
        }
        d.setRyo(d.getRyo() + total);
        player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.CHAIN_PLACE, SoundSource.PLAYERS, 0.6f, 1.6f);
        player.displayClientMessage(Component.translatable("message.shinobiarts.deposited", formatRyo(total)).withStyle(ChatFormatting.GOLD), true);
        player.containerMenu.broadcastChanges();
        sync(player);
    }

    /** Turns Ryo into coin items. Coins that don't fit are dropped at the player's feet. */
    public static void withdraw(ServerPlayer player, CoinItem.Coin coin, int count) {
        NinjaData d = NinjaData.get(player);
        if (d == null || !hasWallet(player) || count <= 0) return;
        int n = (int) Math.min(Math.min(count, 64), d.getRyo() / coin.value());
        if (n <= 0) {
            player.displayClientMessage(Component.translatable("message.shinobiarts.not_enough_ryo",
                    formatRyo(coin.value()), formatRyo(d.getRyo())).withStyle(ChatFormatting.RED), true);
            return;
        }
        d.setRyo(d.getRyo() - (long) n * coin.value());
        ItemStack stack = new ItemStack(ModItems.coin(coin), n);
        player.getInventory().add(stack); // shrinks the stack by however much fit
        if (!stack.isEmpty()) player.drop(stack, false);
        player.serverLevel().playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.CHAIN_PLACE, SoundSource.PLAYERS, 0.6f, 1.2f);
        player.containerMenu.broadcastChanges();
        sync(player);
    }

    public static String formatRyo(long amount) {
        return NumberFormat.getIntegerInstance(Locale.US).format(amount);
    }
}
