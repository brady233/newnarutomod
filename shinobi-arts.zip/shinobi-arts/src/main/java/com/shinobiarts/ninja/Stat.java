package com.shinobiarts.ninja;

import com.shinobiarts.Config;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

/** The seven stats players spend points on. Effects are applied in PlayerDataManager and CommonEvents. */
public enum Stat {
    TAIJUTSU("taijutsu", ChatFormatting.RED),
    KENJUTSU("kenjutsu", ChatFormatting.GRAY),
    GENJUTSU("genjutsu", ChatFormatting.DARK_PURPLE),
    MEDICAL("medical", ChatFormatting.GREEN),
    SPEED("speed", ChatFormatting.AQUA),
    NINJUTSU("ninjutsu", ChatFormatting.BLUE),
    SENJUTSU("senjutsu", ChatFormatting.DARK_GREEN);

    private final String id;
    private final ChatFormatting color;

    Stat(String id, ChatFormatting color) {
        this.id = id;
        this.color = color;
    }

    public String id() {
        return id;
    }

    public ChatFormatting color() {
        return color;
    }

    public int cap() {
        return this == SPEED ? Config.i(Config.SPEED_CAP) : Config.i(Config.STAT_CAP);
    }

    public MutableComponent displayName() {
        return Component.translatable("stat.shinobiarts." + id).withStyle(color);
    }

    public MutableComponent description() {
        return Component.translatable("stat.shinobiarts." + id + ".desc");
    }

    public static Stat byId(String id) {
        for (Stat s : values()) {
            if (s.id.equals(id)) return s;
        }
        return null;
    }
}
