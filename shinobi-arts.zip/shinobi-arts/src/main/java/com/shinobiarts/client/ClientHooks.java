package com.shinobiarts.client;

import net.minecraft.client.Minecraft;

/** Client-only entry points that common code may call through DistExecutor. */
public final class ClientHooks {
    private ClientHooks() {}

    public static void openWallet() {
        Minecraft.getInstance().setScreen(new WalletScreen());
    }

    public static void openStats() {
        Minecraft.getInstance().setScreen(new StatScreen());
    }
}
