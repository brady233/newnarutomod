package com.shinobiarts.client;

import com.shinobiarts.item.CoinItem;
import com.shinobiarts.network.ActionPacket;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.PlayerDataManager;
import com.shinobiarts.registry.ModItems;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

import java.util.EnumMap;
import java.util.Map;

/**
 * The Frog Wallet: shows your Ryo and lets you deposit coins from your inventory or withdraw coins.
 * It has no item slots, so nothing but Ryo can ever go in. All transfers happen on the server.
 */
public class WalletScreen extends Screen {
    private static final int ROW_H = 30;
    private final Map<CoinItem.Coin, Button[]> buttons = new EnumMap<>(CoinItem.Coin.class);
    private Button depositAll;
    private int left;
    private int top;

    public WalletScreen() {
        super(Component.translatable("screen.shinobiarts.wallet"));
    }

    @Override
    protected void init() {
        left = this.width / 2 - 130;
        top = Math.max(10, this.height / 2 - 90);
        for (CoinItem.Coin coin : CoinItem.Coin.values()) {
            int y = top + 50 + coin.ordinal() * ROW_H;
            Button deposit = addRenderableWidget(Button.builder(Component.translatable("screen.shinobiarts.deposit"),
                    b -> ModNetwork.toServer(new ActionPacket(ActionPacket.DEPOSIT, coin.ordinal(), 0))).bounds(left + 120, y, 50, 20).build());
            Button one = addRenderableWidget(Button.builder(Component.literal("-1"),
                    b -> ModNetwork.toServer(new ActionPacket(ActionPacket.WITHDRAW, coin.ordinal(), 1))).bounds(left + 175, y, 38, 20).build());
            Button ten = addRenderableWidget(Button.builder(Component.literal("-10"),
                    b -> ModNetwork.toServer(new ActionPacket(ActionPacket.WITHDRAW, coin.ordinal(), 10))).bounds(left + 217, y, 42, 20).build());
            buttons.put(coin, new Button[]{deposit, one, ten});
        }
        int bottom = top + 50 + CoinItem.Coin.values().length * ROW_H + 8;
        depositAll = addRenderableWidget(Button.builder(Component.translatable("screen.shinobiarts.deposit_all"),
                b -> ModNetwork.toServer(new ActionPacket(ActionPacket.DEPOSIT, -1, 0))).bounds(left, bottom, 150, 20).build());
        addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, b -> onClose()).bounds(left + 160, bottom, 100, 20).build());
        tick();
    }

    private int countInInventory(CoinItem.Coin coin) {
        if (this.minecraft == null || this.minecraft.player == null) return 0;
        Inventory inv = this.minecraft.player.getInventory();
        int count = 0;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (s.getItem() instanceof CoinItem c && c.coin() == coin) count += s.getCount();
        }
        return count;
    }

    @Override
    public void tick() {
        NinjaData d = ClientNinjaData.get();
        boolean any = false;
        for (CoinItem.Coin coin : CoinItem.Coin.values()) {
            Button[] b = buttons.get(coin);
            int have = countInInventory(coin);
            any |= have > 0;
            b[0].active = have > 0;
            b[1].active = d.getRyo() >= coin.value();
            b[2].active = d.getRyo() >= coin.value() * 10L;
        }
        depositAll.active = any;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        NinjaData d = ClientNinjaData.get();
        g.fill(left - 10, top - 8, left + 270, top + 50 + CoinItem.Coin.values().length * ROW_H + 36, 0xC0101810);
        g.drawCenteredString(this.font, this.title, this.width / 2, top, 0x9FE07A);

        // Balance
        g.renderItem(new ItemStack(ModItems.coin(CoinItem.Coin.GOLD)), left, top + 18);
        g.pose().pushPose();
        g.pose().translate(left + 22, top + 20, 0);
        g.pose().scale(1.5f, 1.5f, 1f);
        g.drawString(this.font, PlayerDataManager.formatRyo(d.getRyo()) + " Ryo", 0, 0, 0xF2C230, true);
        g.pose().popPose();

        // Coin rows
        for (CoinItem.Coin coin : CoinItem.Coin.values()) {
            int y = top + 50 + coin.ordinal() * ROW_H;
            g.renderItem(new ItemStack(ModItems.coin(coin)), left, y + 2);
            g.drawString(this.font, Component.translatable("item.shinobiarts." + coin.id() + "_ryo"), left + 20, y + 1, 0xFF000000 | coin.rgb(), true);
            g.drawString(this.font, Component.translatable("screen.shinobiarts.coin_info",
                    PlayerDataManager.formatRyo(coin.value()), countInInventory(coin)), left + 20, y + 11, 0xAAAAAA, false);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
