package com.shinobiarts.client;

import com.shinobiarts.Config;
import com.shinobiarts.network.ActionPacket;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.NinjaData;
import com.shinobiarts.ninja.PlayerDataManager;
import com.shinobiarts.ninja.Stat;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;

import java.util.EnumMap;
import java.util.Map;

/**
 * The stat menu (J): level, XP, unspent points, the seven stats with "+" buttons
 * (shift-click adds 5), and a Ryo-priced reset. The server validates every click.
 */
public class StatScreen extends Screen {
    private static final int ROW_H = 22;
    private final Map<Stat, Button> plusButtons = new EnumMap<>(Stat.class);
    private Button resetButton;
    private int panelLeft;
    private int panelTop;

    public StatScreen() {
        super(Component.translatable("screen.shinobiarts.stats"));
    }

    @Override
    protected void init() {
        panelLeft = this.width / 2 - 150;
        panelTop = Math.max(8, this.height / 2 - 115);
        int rowsTop = panelTop + 66;
        for (Stat stat : Stat.values()) {
            int y = rowsTop + stat.ordinal() * ROW_H;
            Button plus = Button.builder(Component.literal("+"), b -> {
                        int amount = hasShiftDown() ? 5 : 1;
                        ModNetwork.toServer(new ActionPacket(ActionPacket.ALLOCATE_STAT, stat.ordinal(), amount));
                    })
                    .bounds(panelLeft + 124, y, 20, 18)
                    .tooltip(Tooltip.create(stat.description().copy().append("\n")
                            .append(Component.translatable("screen.shinobiarts.shift_add").withStyle(ChatFormatting.GRAY))))
                    .build();
            plusButtons.put(stat, plus);
            addRenderableWidget(plus);
        }
        int bottom = rowsTop + Stat.values().length * ROW_H + 6;
        resetButton = addRenderableWidget(Button.builder(Component.empty(),
                        b -> this.minecraft.setScreen(new ResetConfirmScreen(this)))
                .bounds(panelLeft, bottom, 190, 20).build());
        addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, b -> onClose())
                .bounds(panelLeft + 200, bottom, 100, 20).build());
        refresh();
    }

    private void refresh() {
        NinjaData d = ClientNinjaData.get();
        for (Stat stat : Stat.values()) {
            plusButtons.get(stat).active = d.availablePoints() > 0 && d.stat(stat) < stat.cap();
        }
        resetButton.setMessage(Component.translatable("screen.shinobiarts.reset_button",
                PlayerDataManager.formatRyo(d.resetCost())));
        resetButton.active = d.allocatedPoints() > 0;
    }

    @Override
    public void tick() {
        refresh();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g);
        NinjaData d = ClientNinjaData.get();
        int x = panelLeft;
        int y = panelTop;
        g.fill(x - 8, y - 6, x + 308, y + 66 + Stat.values().length * ROW_H + 34, 0xC0101018);

        g.drawCenteredString(this.font, this.title, this.width / 2, y, 0xFFFFFF);

        // Level + XP bar
        g.drawString(this.font, Component.translatable("screen.shinobiarts.level", d.getLevel()), x, y + 16, 0xFFD34A, true);
        int barX = x + 70, barY = y + 17, barW = 230;
        g.fill(barX - 1, barY - 1, barX + barW + 1, barY + 8, 0xFF0B0B12);
        g.fill(barX, barY, barX + barW, barY + 7, 0xFF22222E);
        float frac = d.isMaxLevel() ? 1f : Math.min(1f, d.getXp() / (float) Math.max(1, d.xpToNext()));
        g.fill(barX, barY, barX + Math.round(barW * frac), barY + 7, 0xFF7ED957);
        Component xpText = d.isMaxLevel() ? Component.translatable("screen.shinobiarts.max_level")
                : Component.translatable("screen.shinobiarts.xp", d.getXp(), d.xpToNext());
        g.drawCenteredString(this.font, xpText, barX + barW / 2, barY + 10, 0xCFCFCF);

        // Points + Ryo
        g.drawString(this.font, Component.translatable("screen.shinobiarts.points", d.availablePoints())
                .withStyle(d.availablePoints() > 0 ? ChatFormatting.GREEN : ChatFormatting.GRAY), x, y + 42, 0xFFFFFF, true);
        Component ryo = Component.translatable("screen.shinobiarts.ryo", PlayerDataManager.formatRyo(d.getRyo()));
        g.drawString(this.font, ryo, x + 300 - this.font.width(ryo), y + 42, 0xF2C230, true);

        // Stat rows
        int rowsTop = y + 66;
        for (Stat stat : Stat.values()) {
            int ry = rowsTop + stat.ordinal() * ROW_H;
            g.fill(x - 2, ry - 2, x + 302, ry + 20, stat.ordinal() % 2 == 0 ? 0x30FFFFFF : 0x18FFFFFF);
            g.drawString(this.font, stat.displayName(), x + 2, ry + 5, 0xFFFFFF, true);
            String value = d.stat(stat) + " / " + stat.cap();
            g.drawString(this.font, value, x + 118 - this.font.width(value), ry + 5, 0xFFFFFF, true);
            g.drawString(this.font, effectText(stat, d), x + 150, ry + 5, 0xAFAFC0, true);
        }

        super.render(g, mouseX, mouseY, partialTick);
    }

    /** What the current points in a stat are doing, e.g. "+3.5 fist damage". */
    private static MutableComponent effectText(Stat stat, NinjaData d) {
        int p = d.stat(stat);
        return switch (stat) {
            case TAIJUTSU -> Component.translatable("stat.shinobiarts.effect.taijutsu", fmt(p * Config.d(Config.TAIJUTSU_PER_POINT)));
            case KENJUTSU -> Component.translatable("stat.shinobiarts.effect.kenjutsu", fmt(p * Config.d(Config.KENJUTSU_PER_POINT)));
            case GENJUTSU -> Component.translatable("stat.shinobiarts.effect.genjutsu", Math.round((d.genjutsuMultiplier() - 1f) * 100));
            case MEDICAL -> Component.translatable("stat.shinobiarts.effect.medical", fmt(p * Config.d(Config.HEALTH_PER_MEDICAL)));
            case SPEED -> Component.translatable("stat.shinobiarts.effect.speed", Math.round(p * Config.d(Config.SPEED_PER_POINT) * 100));
            case NINJUTSU -> Component.translatable("stat.shinobiarts.effect.ninjutsu", (int) d.maxChakra());
            case SENJUTSU -> Component.translatable("stat.shinobiarts.effect.senjutsu", (int) d.maxSenjutsu());
        };
    }

    private static String fmt(double v) {
        return v == Math.floor(v) ? String.valueOf((long) v) : String.format("%.1f", v);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
