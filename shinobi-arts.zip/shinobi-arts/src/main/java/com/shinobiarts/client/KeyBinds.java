package com.shinobiarts.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.settings.KeyConflictContext;
import org.lwjgl.glfw.GLFW;

/**
 * Default keys; players can rebind them under Options > Controls > Shinobi Arts.
 * Ninja Jump uses the vanilla Sneak + Jump keys, so it follows whatever those are bound to.
 */
public final class KeyBinds {
    public static final String CATEGORY = "key.categories.shinobiarts";

    public static final KeyMapping CAST = key("cast", GLFW.GLFW_KEY_R);
    public static final KeyMapping NEXT = key("next", GLFW.GLFW_KEY_G);
    public static final KeyMapping PREV = key("prev", GLFW.GLFW_KEY_H);
    public static final KeyMapping DOJUTSU = key("dojutsu", GLFW.GLFW_KEY_V);
    public static final KeyMapping CHARGE = key("charge", GLFW.GLFW_KEY_Z);
    public static final KeyMapping SAGE = key("sage", GLFW.GLFW_KEY_B);
    public static final KeyMapping STATS = key("stats", GLFW.GLFW_KEY_J);

    public static final KeyMapping[] ALL = {CAST, NEXT, PREV, DOJUTSU, CHARGE, SAGE, STATS};

    private static KeyMapping key(String name, int keyCode) {
        return new KeyMapping("key.shinobiarts." + name, KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, keyCode, CATEGORY);
    }

    private KeyBinds() {}
}
