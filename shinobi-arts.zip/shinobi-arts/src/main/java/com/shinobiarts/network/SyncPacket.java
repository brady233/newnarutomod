package com.shinobiarts.network;

import com.shinobiarts.client.ClientNinjaData;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> client: the player's full ninja data. */
public class SyncPacket {
    private final CompoundTag tag;

    public SyncPacket(CompoundTag tag) {
        this.tag = tag;
    }

    public SyncPacket(FriendlyByteBuf buf) {
        CompoundTag read = buf.readNbt();
        this.tag = read == null ? new CompoundTag() : read;
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeNbt(tag);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientNinjaData.apply(tag));
    }
}
