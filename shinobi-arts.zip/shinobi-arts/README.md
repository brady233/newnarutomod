# Shinobi Arts — a ninja mod for Minecraft Forge 1.20.1

Chakra, releases and jutsu, levels and stats, Ryo, and ninja tools.

## Building the jar

**With GitHub (no Java needed):** upload `shinobi-arts.zip` (still zipped) to your repository, replacing the
old one. The "Build mod jar" workflow runs on its own. When it's green, download **shinobiarts-jar**,
unzip it, and put `shinobiarts-1.0.0.jar` in your profile's `mods` folder.

**On your PC:** install JDK 17, open a terminal in this folder and run `gradlew build`
(`./gradlew build` on Mac/Linux). The jar appears in `build/libs/`.

## Controls (rebind in Options → Controls → Shinobi Arts)

| Key | Action |
|---|---|
| **R** | Cast the selected jutsu of the release you're holding |
| **G / H** | Move the jutsu arrow right / left |
| **J** | Stats menu |
| **Z** (hold) | Charge chakra (standing still also gathers Senjutsu) |
| **B** | Toggle Sage Mode |
| **V** | Toggle Sharingan / Byakugan (Uchiha / Hyuga) |
| **Shift + Space** | Ninja Jump (15 chakra) |

## How it works

### Releases and jutsu
- There are 7 release scrolls: Fire, Water, Wind, Lightning, Earth, Yin Yang, and Ninjutsu.
  **Hold one** (either hand) to equip it. The HUD shows its jutsu slots.
- New players get the **Ninjutsu** release scroll, empty at first.
- **Chakra Paper** reveals your nature affinity and gives you that release scroll. **Training Scrolls**
  unlock more natures, including Yin Yang.
- **Jutsu scrolls** teach a jutsu permanently and add it to its release's slots. Shadow Clone,
  Rasengan, Substitution, Body Flicker and clan jutsu go in Ninjutsu.
- Tier 2 jutsu need level 5 and tier 3 need level 15 (configurable).

### Levels and stats
- Gain XP from **Ninja EXP Bottles** (100 XP each). Update 2 adds quests and bandits that give XP and Ryo.
- Each level gives **3 stat points** and **250 Ryo**.
- Spend points in the stats menu (J); shift-click adds 5. Resetting refunds every point for Ryo
  (500 + 100 per level), with a confirmation screen.

| Stat | Effect per point (default) |
|---|---|
| Taijutsu | +0.5 punch damage (bare hand or holding a release scroll) |
| Kenjutsu | +0.4 sword damage |
| Genjutsu | +2% Sharingan dodge/copy range, Amaterasu, Shadow Possession and Yin illusions |
| Medical | +1 max health (half a heart), stronger Yang healing |
| Speed | +1% movement speed (max 50 points) |
| Ninjutsu | +5 max chakra, slightly faster chakra regen |
| Senjutsu | +10 max natural energy for Sage Mode |

### Ryo and the Frog Wallet
- Coins: **Bronze = 100**, **Silver = 500**, **Gold = 1,000** Ryo.
- Right-click the **Frog Wallet** to deposit coins or withdraw them.
- Your Ryo is stored on your player, not in the wallet item. Dropping, losing or copying a wallet never
  loses or duplicates money, and every transfer is checked by the server.

### Sage Mode
Invest in Senjutsu, then hold **Z** while standing still to gather natural energy (green bar).
Press **B** for Sage Mode: Strength, Resistance, Jump Boost and +25% jutsu damage until the energy runs out.

## Recipes (shapeless unless noted)

**Blank Scroll** = 3 paper + stick.

| Item | Recipe |
|---|---|
| Release scroll | Blank Scroll + 4 of the release's item (see below) |
| Training Scroll | Blank Scroll + 3 of the nature's item + emerald |
| Tier 1 jutsu scroll | Blank Scroll + 2 of the nature's item |
| Tier 2 / 3 jutsu scroll | ... + gold ingot / diamond |
| Frog Wallet | 2 leather + slime ball + lime dye + string |
| Kubikiribocho (shaped) | 2 iron blocks diagonally above a netherite ingot |
| Kunai ×3 (shaped) | iron ingot diagonally above a stick |
| Shuriken ×4 (shaped) | iron ingot in a cross of 4 iron nuggets |
| Explosive Tag ×2 | paper + gunpowder + redstone |
| Chakra Pill ×2 | sugar + sweet berries + glowstone dust |
| Chakra Paper ×2 | paper + lapis lazuli |

Nature items: Fire = blaze powder, Water = prismarine shard, Wind = feather, Lightning = copper ingot,
Earth = clay ball, Yin Yang = amethyst shard, Ninjutsu = lapis lazuli.
Yin jutsu use fermented spider eyes, Yang jutsu use glistering melon; Ninjutsu and clan jutsu have special
recipes (see `tools/make_resources.py`).

## Admin commands (operators)

```
/shinobi info [player]
/shinobi xp <player> <amount>
/shinobi level <player> <level>
/shinobi ryo <player> add|set <amount>
/shinobi release <player> <fire|water|wind|lightning|earth|yin_yang|ninjutsu>
/shinobi learn <player> <jutsu|all>        /shinobi forget <player> <jutsu|all>
/shinobi nature <player> <nature>          /shinobi clan <player> <clan>
/shinobi refill <player>                   /shinobi reset <player>
```

Quick test: `/shinobi learn @s all`, `/shinobi level @s 20`, `/shinobi ryo @s add 5000`,
`/shinobi release @s fire`.

## Config

Each world has `saves/<world>/serverconfig/shinobiarts-server.toml`, and servers send it to every player
who joins. It holds XP curve, points and Ryo per level, every stat's value per point, stat caps,
reset cost, chakra regen, Senjutsu rates, Ninja Jump cost/cooldown/power, damage and cooldown
multipliers, and jutsu griefing.

## Art and models

- The Fire/Water/Wind/Lightning/Earth icons are cut from your chart by `tools/cut_nature_icons.py`.
- **The Yin Yang and Ninjutsu icons are placeholders.** To replace one, save a square PNG as
  `src/main/resources/assets/shinobiarts/textures/nature/<yin_yang|ninjutsu>.png`, create an empty file
  `.<name>.provided` next to it, and run `python3 tools/make_textures.py` to rebuild the item icons.
- 3D models come from `tools/source_art/*.glb`. `python3 tools/convert_models.py` turns them into Forge
  OBJ models: kunai, Kubikiribocho, and the four scrolls (green = jutsu scrolls, 天 = release scrolls,
  地 = training scrolls, beige = blank scroll). Each item holds exactly one scroll.
- Inventory icons stay flat so they're easy to read; the 3D model shows in your hand, on the ground and in flight.

## Saves

All player data lives in one place (`ninja/NinjaData.java`, changed only through
`ninja/PlayerDataManager.java`). It has a `DataVersion`; saves from the first version are upgraded
automatically: learned jutsu are kept, and old chakra training becomes stat points.

## Project layout

```
src/main/java/com/shinobiarts/
  ninja/      player data (NinjaData), PlayerDataManager, clans, natures, stats
  jutsu/      jutsu list, effects, casting, per-tick logic, key actions
  item/       release scrolls, jutsu/training scrolls, coins, wallet, EXP bottle, weapons
  entity/     jutsu projectiles, thrown weapons, explosive tags, shadow clones
  client/     HUD, stats/reset/wallet screens, keybinds, renderers
  network/    key/menu requests (client -> server) and data sync (server -> client)
  command/    /shinobi
tools/        generators for icons, 3D models, models/recipes/lang (run with Python 3)
```
