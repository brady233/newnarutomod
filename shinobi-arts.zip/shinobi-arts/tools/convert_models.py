"""
Converts the provided .glb models (tools/source_art/*.glb) into Forge OBJ models + textures.

Each model is laid out like a Minecraft item sprite: handle at the bottom-left, tip toward the top-right,
flat side facing the camera, inside the 0..1 block space. That way vanilla-style held-item transforms
put the grip in the player's hand. Run: python3 tools/convert_models.py [preview_dir]
Needs: pip install trimesh pygltflib pillow numpy
"""
import io
import math
import os
import sys

import numpy as np
import pygltflib
import trimesh
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "source_art")
ASSETS = os.path.join(HERE, "..", "src", "main", "resources", "assets", "shinobiarts")
OBJ_DIR = os.path.join(ASSETS, "models", "item", "obj")
TEX_DIR = os.path.join(ASSETS, "textures", "item", "model")
ICON_DIR = os.path.join(ASSETS, "textures", "item")

DIAG = np.array([1.0, 1.0, 0.0]) / math.sqrt(2)
CROSS = np.array([-1.0, 1.0, 0.0]) / math.sqrt(2)

# name: settings
#   parts      - geometry names to keep (None = all)
#   handle     - which end of the long axis is the handle: "+" or "-" (along the model's main axis)
#   length     - length along the diagonal, in blocks
#   grip       - (fraction of length from the handle end, target x=y coordinate) for the hand position;
#                None = center the model in the block (for things held in the middle, like scrolls)
#   roll       - extra rotation (degrees) around the long axis, to choose which side faces out
#   tex        - texture size to downscale to
MODELS = {
    "kunai": {"src": "kunai.glb", "parts": None, "handle": "+", "length": 1.2, "grip": (0.13, 0.16), "roll": 0, "tex": 256},
    "zabuza_blade": {"src": "zabuza_blade.glb", "parts": None, "handle": "-", "length": 2.1, "grip": (0.08, 0.14), "roll": 0, "tex": 512},
    "scroll_jutsu": {"src": "scrolls.glb", "parts": ["Circle.002_Material.001_0"], "handle": "+", "length": 0.95, "grip": None, "roll": 135, "tex": 256},
    "scroll_release": {"src": "scrolls.glb", "parts": ["Circle.001_Material.004_0"], "handle": "+", "length": 0.95, "grip": None, "roll": 135, "tex": 256},
    "scroll_training": {"src": "scrolls.glb", "parts": ["Circle.003_Material.003_0"], "handle": "+", "length": 0.95, "grip": None, "roll": 135, "tex": 256},
    "scroll_blank": {"src": "scrolls.glb", "parts": ["Circle.004_Material.002_0"], "handle": "+", "length": 0.95, "grip": None, "roll": 135, "tex": 256},
}


def load_parts(path, parts):
    """Returns [(name, mesh_in_world_space, material_index)] and the glTF images by material."""
    gltf = pygltflib.GLTF2().load(path)
    blob = gltf.binary_blob()
    mat_images = {}
    for mi, m in enumerate(gltf.materials):
        pbr = m.pbrMetallicRoughness
        if pbr and pbr.baseColorTexture is not None:
            img = gltf.images[gltf.textures[pbr.baseColorTexture.index].source]
            bv = gltf.bufferViews[img.bufferView]
            mat_images[mi] = Image.open(io.BytesIO(blob[bv.byteOffset: bv.byteOffset + bv.byteLength])).convert("RGBA")
        else:
            color = [int(255 * c) for c in (pbr.baseColorFactor if pbr else [1, 1, 1, 1])]
            mat_images[mi] = Image.new("RGBA", (16, 16), tuple(color))
    mesh_material = {}
    for i, mesh in enumerate(gltf.meshes):
        mesh_material[mesh.name] = mesh.primitives[0].material or 0

    scene = trimesh.load(path, force="scene")
    out = []
    for node in scene.graph.nodes_geometry:
        transform, gname = scene.graph[node]
        if parts is not None and gname not in parts:
            continue
        mesh = scene.geometry[gname].copy()
        mesh.apply_transform(transform)
        mat = mesh_material.get(gname, mesh_material.get(gname.rsplit("_", 1)[0], 0))
        out.append((gname, mesh, mat))
    return out, mat_images


def layout(meshes, cfg):
    verts = np.vstack([m.vertices for _, m, _ in meshes])
    center = verts.mean(0)
    _, _, vt = np.linalg.svd(verts - center, full_matrices=False)
    a, b = vt[0], vt[1]
    proj = (verts - center) @ a
    # point a from handle to tip
    if (cfg["handle"] == "-" and a[np.argmax(np.abs(a))] < 0) or (cfg["handle"] == "+" and a[np.argmax(np.abs(a))] > 0):
        a = -a
    roll = math.radians(cfg["roll"])
    c = np.cross(a, b)
    b, c = b * math.cos(roll) + c * math.sin(roll), -b * math.sin(roll) + c * math.cos(roll)
    rot = np.outer(DIAG, a) + np.outer(CROSS, b) + np.outer(np.array([0, 0, 1.0]), c)

    proj = (verts - center) @ a
    lo, hi = proj.min(), proj.max()
    scale = cfg["length"] / (hi - lo)

    def place(v):
        local = (v - center) @ rot.T * scale  # rotated + scaled, centered at origin
        return local

    placed_all = place(verts)
    along = placed_all @ DIAG
    handle_end = along.min()
    if cfg["grip"] is None:
        mid = (along.min() + along.max()) / 2
        offset = np.array([0.5, 0.5, 0.5]) - DIAG * mid
    else:
        frac, target = cfg["grip"]
        grip_along = handle_end + frac * cfg["length"]
        offset = np.array([target, target, 0.5]) - DIAG * grip_along
    z_mid = (placed_all[:, 2].min() + placed_all[:, 2].max()) / 2
    offset[2] = 0.5 - z_mid
    return lambda v: place(v) + offset, rot


def write_obj(name, meshes, mat_images, cfg):
    os.makedirs(OBJ_DIR, exist_ok=True)
    os.makedirs(TEX_DIR, exist_ok=True)
    transform, rot = layout(meshes, cfg)
    lines = [f"# {name} - converted from provided art by tools/convert_models.py", f"mtllib {name}.mtl"]
    mtl = []
    textures = {}
    v_off = vt_off = vn_off = 1
    all_tris = []
    for idx, (gname, mesh, mat) in enumerate(meshes):
        key = f"tex{len(textures)}" if mat not in [m for m, _ in textures.values()] else None
        if key is not None:
            tex_name = f"{name}_{len(textures)}"
            img = mat_images[mat]
            size = min(cfg["tex"], img.width)
            img.resize((size, size), Image.LANCZOS).save(os.path.join(TEX_DIR, tex_name + ".png"))
            textures[key] = (mat, tex_name)
            mtl += [f"newmtl {key}", "Kd 1.0 1.0 1.0", "d 1.0", f"map_Kd #{key}", ""]
        use = next(k for k, (m, _) in textures.items() if m == mat)
        v = transform(mesh.vertices)
        n = mesh.vertex_normals @ rot.T
        uv = mesh.visual.uv  # trimesh gives bottom-up V; Minecraft/Forge expect top-down
        uv_top = np.column_stack([uv[:, 0], 1.0 - uv[:, 1]])
        lines.append(f"o {gname.replace(' ', '_')}")
        lines.append(f"usemtl {use}")
        lines += [f"v {x:.5f} {y:.5f} {z:.5f}" for x, y, z in v]
        lines += [f"vt {u:.5f} {w:.5f}" for u, w in uv_top]
        lines += [f"vn {x:.4f} {y:.4f} {z:.4f}" for x, y, z in n]
        for f in mesh.faces:
            a, b, c = (int(i) for i in f)
            lines.append(f"f {a + v_off}/{a + vt_off}/{a + vn_off} {b + v_off}/{b + vt_off}/{b + vn_off} {c + v_off}/{c + vt_off}/{c + vn_off}")
            all_tris.append((v[[a, b, c]], uv_top[[a, b, c]], n[[a, b, c]], mat))
        v_off += len(v)
        vt_off += len(uv)
        vn_off += len(n)
    open(os.path.join(OBJ_DIR, name + ".obj"), "w").write("\n".join(lines) + "\n")
    open(os.path.join(OBJ_DIR, name + ".mtl"), "w").write("\n".join(mtl))
    tex_map = {k: f"shinobiarts:item/model/{t}" for k, (_, t) in textures.items()}
    bounds = np.vstack([t[0] for t in all_tris])
    return tex_map, all_tris, (bounds.min(0), bounds.max(0))


def render(tris, mat_images, size, view_min=0.0, view_max=1.0, light=True):
    """Tiny software rasterizer: orthographic front view of the XY plane (used for previews and GUI icons)."""
    img = np.zeros((size, size, 4), dtype=np.float32)
    zbuf = np.full((size, size), -1e9, dtype=np.float32)
    texs = {m: np.asarray(im.convert("RGBA"), dtype=np.float32) / 255.0 for m, im in mat_images.items()}
    span = view_max - view_min
    light_dir = np.array([-0.4, 0.6, 0.7]); light_dir /= np.linalg.norm(light_dir)
    for verts, uv, normals, mat in tris:
        px = (verts[:, 0] - view_min) / span * size
        py = (1 - (verts[:, 1] - view_min) / span) * size
        x0, x1 = int(max(0, math.floor(px.min()))), int(min(size - 1, math.ceil(px.max())))
        y0, y1 = int(max(0, math.floor(py.min()))), int(min(size - 1, math.ceil(py.max())))
        if x1 < x0 or y1 < y0:
            continue
        xs, ys = np.meshgrid(np.arange(x0, x1 + 1) + 0.5, np.arange(y0, y1 + 1) + 0.5)
        d = (py[1] - py[2]) * (px[0] - px[2]) + (px[2] - px[1]) * (py[0] - py[2])
        if abs(d) < 1e-9:
            continue
        w0 = ((py[1] - py[2]) * (xs - px[2]) + (px[2] - px[1]) * (ys - py[2])) / d
        w1 = ((py[2] - py[0]) * (xs - px[2]) + (px[0] - px[2]) * (ys - py[2])) / d
        w2 = 1 - w0 - w1
        inside = (w0 >= -1e-4) & (w1 >= -1e-4) & (w2 >= -1e-4)
        if not inside.any():
            continue
        z = w0 * verts[0, 2] + w1 * verts[1, 2] + w2 * verts[2, 2]
        sub = zbuf[y0:y1 + 1, x0:x1 + 1]
        mask = inside & (z > sub)
        if not mask.any():
            continue
        tex = texs[mat]
        th, tw = tex.shape[:2]
        u = w0 * uv[0, 0] + w1 * uv[1, 0] + w2 * uv[2, 0]
        v = w0 * uv[0, 1] + w1 * uv[1, 1] + w2 * uv[2, 1]
        tx = np.clip((u % 1.0) * tw, 0, tw - 1).astype(int)
        ty = np.clip((v % 1.0) * th, 0, th - 1).astype(int)
        col = tex[ty, tx].copy()
        if light:
            nrm = normals.mean(0)
            nrm = nrm / (np.linalg.norm(nrm) + 1e-9)
            shade = 0.55 + 0.45 * abs(float(nrm @ light_dir))
            col[..., :3] *= shade
        col[..., 3] = 1.0
        region = img[y0:y1 + 1, x0:x1 + 1]
        region[mask] = col[mask]
        sub[mask] = z[mask]
    return Image.fromarray((np.clip(img, 0, 1) * 255).astype(np.uint8), "RGBA")


def main():
    preview_dir = sys.argv[1] if len(sys.argv) > 1 else None
    results = {}
    for name, cfg in MODELS.items():
        meshes, images = load_parts(os.path.join(SRC, cfg["src"]), cfg["parts"])
        tex_map, tris, (lo, hi) = write_obj(name, meshes, images, cfg)
        results[name] = {"textures": tex_map, "min": lo.round(3).tolist(), "max": hi.round(3).tolist()}
        # A rendered inventory icon (used for Zabuza's blade, which has no hand-drawn icon).
        view_lo, view_hi = min(lo[0], lo[1]), max(hi[0], hi[1])
        pad = (view_hi - view_lo) * 0.04
        icon = render(tris, images, 128, view_lo - pad, view_hi + pad).resize((32, 32), Image.LANCZOS)
        icon.save(os.path.join(ICON_DIR, name + "_icon.png"))
        if preview_dir:
            render(tris, images, 384, -0.25, 2.25 if name == "zabuza_blade" else 1.25).save(os.path.join(preview_dir, name + "_preview.png"))
        print(f"{name}: {sum(len(m.faces) for _, m, _ in meshes)} triangles, textures {list(tex_map.values())}, "
              f"bounds {results[name]['min']} .. {results[name]['max']}")
    return results


if __name__ == "__main__":
    main()
